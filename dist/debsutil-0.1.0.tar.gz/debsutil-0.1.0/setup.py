# -*- coding: utf-8 -*-
from distutils.core import setup

packages = \
['debsutil']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'debsutil',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'debswade',
    'author_email': 'deborah.wade@hivehome.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/debswade/debsutil',
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=2.7,<3.0',
}


setup(**setup_kwargs)
